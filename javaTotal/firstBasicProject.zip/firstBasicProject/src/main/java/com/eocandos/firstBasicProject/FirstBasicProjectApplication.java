package com.eocandos.firstBasicProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstBasicProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstBasicProjectApplication.class, args);
	}

}
